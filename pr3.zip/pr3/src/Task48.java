import java.util.*;

public class Task48 {
    public static List<Integer> u(int n) {
        TreeSet<Integer> set = new TreeSet<>();
        Queue<Integer> q = new LinkedList<>();
        set.add(1);
        q.add(1);
        while (set.size() < n) {
            int x = q.poll();
            int y = 2 * x + 1;
            int z = 3 * x + 1;
            if (set.add(y)) q.add(y);
            if (set.add(z)) q.add(z);
        }
        return new ArrayList<>(set);
    }

    public static void main(String[] args) {
        System.out.println(u(15));
    }
}
