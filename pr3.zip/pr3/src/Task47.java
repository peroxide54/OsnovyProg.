import java.util.*;

public class Task47 {
    public static List<Integer> snail(int[][] a) {
        List<Integer> r = new ArrayList<>();
        int top = 0, bottom = a.length - 1;
        int left = 0, right = a[0].length - 1;
        while (top <= bottom && left <= right) {
            for (int i = left; i <= right; i++) r.add(a[top][i]);
            top++;
            for (int i = top; i <= bottom; i++) r.add(a[i][right]);
            right--;
            if (top <= bottom) {
                for (int i = right; i >= left; i--) r.add(a[bottom][i]);
                bottom--;
            }
            if (left <= right) {
                for (int i = bottom; i >= top; i--) r.add(a[i][left]);
                left++;
            }
        }
        return r;
    }

    public static void main(String[] args) {
        int[][] a = {
                {1, 2, 3},
                {8, 9, 4},
                {7, 6, 5}
        };
        System.out.println(snail(a));
    }
}
