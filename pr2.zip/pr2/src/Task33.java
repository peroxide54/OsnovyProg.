public class Task33 {
    public static void main(String[] args) {
        long sticks = 10;
        System.out.println("Игра начинается с " + sticks + " палочками");

        while (sticks > 0) {
            long taken = getMove(sticks);
            System.out.println("Игрок берет " + taken + " палочек");
            sticks -= taken;
            System.out.println("Осталось " + sticks + " палочек");
        }
    }

    public static long getMove(long sticks) {
        if (sticks % 2 == 0) {
            return sticks / 2 > 1 ? sticks / 2 : 1;
        } else {
            return 1;
        }
    }
}
