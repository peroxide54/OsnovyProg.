public class Task28 {
    public static String caesarCipher(String text, int shift, boolean right) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (Character.isLetter(c)) {
                char base = Character.isLowerCase(c) ? 'a' : 'A';
                if (right) {
                    c = (char)(base + (c - base + shift) % 26);
                } else {
                    c = (char)(base + (c - base - shift + 26) % 26);
                }
            }
            result.append(c);
        }
        return result.toString();
    }
}