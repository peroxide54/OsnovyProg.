public class Task29 {
    public static int findSquareDifference(int difference) {
        int n = (difference - 1) / 2;
        if (2 * n + 1 == difference) {
            return n;
        }
        return -1;
    }
}