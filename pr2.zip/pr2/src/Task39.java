public class Task39 {
    public static String transformText(String text) {
        String[] words = text.split(" ");
        StringBuilder result = new StringBuilder();

        for (String word : words) {
            if (word.length() > 0) {
                char firstChar = word.charAt(0);
                String rest = word.substring(1);

                if (word.matches(".*[.,!?;:]")) {
                    String punctuation = word.substring(word.length() - 1);
                    rest = word.substring(1, word.length() - 1) + punctuation;
                    result.append(rest).append(firstChar).append("ауч").append(punctuation).append(" ");
                } else {
                    result.append(rest).append(firstChar).append("ауч ");
                }
            }
        }

        return result.toString().trim();
    }
}
