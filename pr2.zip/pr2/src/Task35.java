import java.util.Arrays;
import java.util.Comparator;

public class Task35 {
    public static void main(String[] args) {
        Integer[] weights = {56, 65, 74, 100, 99, 68, 86, 180, 90};

        Arrays.sort(weights, Comparator.comparingInt(Task35::sumOfDigits));

        System.out.println(Arrays.toString(weights));
    }

    private static int sumOfDigits(int number) {
        int sum = 0;
        while (number > 0) {
            sum += number % 10;
            number /= 10;
        }
        return sum;
    }
}
