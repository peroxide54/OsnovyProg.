public class Task30 {
    public static boolean checkNumber(int num, int start) {
        String numStr = String.valueOf(num);
        int sum = 0;
        for (int i = 0; i < numStr.length(); i++) {
            int digit = numStr.charAt(i) - '0';
            sum += Math.pow(digit, start + i);
        }
        return sum == num * start;
    }
}