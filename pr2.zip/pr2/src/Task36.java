import java.util.HashMap;
import java.util.Map;

public class Task36 {
    public static String decryptCaesar(String text, int shift) {
        StringBuilder result = new StringBuilder();
        for (char c : text.toCharArray()) {
            if (Character.isLetter(c)) {
                char base = Character.isLowerCase(c) ? 'a' : 'A';
                c = (char)(base + (c - base - shift + 26) % 26);
            }
            result.append(c);
        }
        return result.toString();
    }

    public static Map<Character, Double> buildFrequencyDictionary(String text) {
        Map<Character, Double> frequencyMap = new HashMap<>();
        int totalLetters = 0;

        for (char c : text.toLowerCase().toCharArray()) {
            if (Character.isLetter(c)) {
                frequencyMap.put(c, frequencyMap.getOrDefault(c, 0.0) + 1);
                totalLetters++;
            }
        }

        for (Map.Entry<Character, Double> entry : frequencyMap.entrySet()) {
            entry.setValue(entry.getValue() / totalLetters * 100);
        }

        return frequencyMap;
    }
}
