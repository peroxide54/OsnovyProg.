import java.util.Scanner;

public class Task37 {
    public static void main(String[] args) {
        int[] secretCode = {1, 2, 3, 4};
        Scanner scanner = new Scanner(System.in);
        int attempts = 0;

        while (attempts < 20) {
            System.out.print("Введите 4 числа: ");
            int[] guess = new int[4];
            for (int i = 0; i < 4; i++) {
                guess[i] = scanner.nextInt();
            }

            int matches = countMatches(secretCode, guess);
            System.out.println("Совпадений: " + matches);

            if (matches == 4) {
                System.out.println("Поздравляем! Вы угадали код!");
                return;
            }

            attempts++;
        }

        System.out.println("Попытки закончились. Код не угадан.");
    }

    private static int countMatches(int[] secret, int[] guess) {
        int count = 0;
        for (int i = 0; i < secret.length; i++) {
            if (secret[i] == guess[i]) {
                count++;
            }
        }
        return count;
    }
}
