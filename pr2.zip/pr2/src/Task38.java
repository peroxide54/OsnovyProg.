import java.util.ArrayList;
import java.util.List;

public class Task38 {
    public static void main(String[] args) {
        List<Integer> players = new ArrayList<>(List.of(1, 2, 3, 4, 5, 6, 7));
        List<Integer> result = new ArrayList<>();
        int index = 0;

        while (players.size() > 1) {
            index = (index + 2) % players.size();
            int removed = players.remove(index);
            result.add(removed);
            System.out.println(players + " => " + removed + " выбыл, результат: " + result);
        }
        result.add(players.get(0));
        System.out.println("Финальный результат: " + result);
    }
}