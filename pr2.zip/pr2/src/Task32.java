import java.math.BigInteger;
import java.util.AbstractMap;
import java.util.Map;

public class Task32 {
    public static Map.Entry<Integer, Integer> analyzeFibonacci(int n) {
        BigInteger fib = fibonacci(n);
        String fibStr = fib.toString();
        int[] digitCounts = new int[10];

        for (char c : fibStr.toCharArray()) {
            digitCounts[c - '0']++;
        }

        int maxCount = 0;
        int digit = 0;
        for (int i = 0; i < 10; i++) {
            if (digitCounts[i] > maxCount || (digitCounts[i] == maxCount && i < digit)) {
                maxCount = digitCounts[i];
                digit = i;
            }
        }

        return new AbstractMap.SimpleEntry<>(maxCount, digit);
    }

    private static BigInteger fibonacci(int n) {
        BigInteger a = BigInteger.ZERO;
        BigInteger b = BigInteger.ONE;
        for (int i = 0; i < n; i++) {
            BigInteger temp = a.add(b);
            a = b;
            b = temp;
        }
        return a;
    }
}