public class Task34 {
    public static void main(String[] args) {
    long sticks = 10;
    long tanyaSticks = 0;
    boolean tanyaTurn = true;

    System.out.println("Игра начинается с " + sticks + " палочками");

    while (sticks > 0) {
        long taken = getOptimalMove(sticks, tanyaTurn);

        if (tanyaTurn) {
            tanyaSticks += taken;
            System.out.println("Таня берет " + taken + " палочек");
        } else {
            System.out.println("Саша берет " + taken + " палочек");
        }

        sticks -= taken;
        tanyaTurn = !tanyaTurn;
    }

    System.out.println("Таня собрала " + tanyaSticks + " палочек");
}

    public static long getOptimalMove(long sticks, boolean isTanya) {
        if (sticks % 2 == 0) {
            if (isTanya) {
                return Math.max(sticks / 2, 1);
            } else {
                return sticks / 2 > 1 ? sticks / 2 : 1;
            }
        } else {
            return 1;
        }
    }
}

}
